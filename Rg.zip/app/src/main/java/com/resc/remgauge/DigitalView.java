package com.resc.remgauge;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.WindowManager;

public class DigitalView extends View {
	
	private Paint labelPaint;
	private Paint roboPaint;
	
	private Paint scalePaint;
	private Paint miscPaint;
	private Paint digitalPaint;
	boolean setLayerType = false;
	static float valMph = 0.0f;
	static int valOt = 0;
	static int valRpm = 0;
	static int valCht = 0;
	static int valOp = 0;
	static int valAfr = 0;
	static int valOd = 0;
    float valVlt = 0.0f;
	float mDigitalTextSize = 55f;
	int mHeight;
	int mWidth;
	
	public DigitalView(Context context) {
		super(context);
		initialize(context, null);
	}

	public DigitalView(Context context, AttributeSet attrs) {
	        super(context, attrs);
	        initialize(context,attrs);
	}

	public DigitalView(Context context, AttributeSet attrs, int defStyle) {
	        super(context, attrs, defStyle);
	        initialize(context,attrs);
	}
	
	String[] mValueArray = {"Mph","This","That","And"};
	
	void initialize(Context context, AttributeSet attrs) {
		screenResolution(context);
		/*
		if ( context != null && attrs != null) {
			TypedArray a = context.obtainStyledAttributes(attrs,R.styleable.Digital);
			int jj = 0;
			jj = a.getInt(R.styleable.Digital_smallFormat, jj);
			mDigitalTextSize = a.getFloat(R.styleable.Digital_valueSize,mDigitalTextSize);
			String aa;
			aa = a.getString(R.styleable.Digital_orderList);
			if ( aa != null )
			{
				mValueArray = aa.split("\\-");
				Log.v("DIGITAL", "hey = " + jj + " aa" + aa+ " jj" + mValueArray[3]);
			}
			
			//int jj = a.getInt(R.styleable.,           totalNotches);
			a.recycle();
		}
		*/
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            setLayerType = true;
        }

		roboPaint = new Paint();
		roboPaint.setColor(Color.GREEN);
		roboPaint.setTextSize(0.087f);
		Typeface textPaintTF = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Bold.ttf");
		roboPaint.setTypeface(Typeface.create(textPaintTF, Typeface.BOLD));
		//textPaint.setTextSize(75);
		roboPaint.setTextAlign(Align.LEFT);
		setLayerType(LAYER_TYPE_SOFTWARE, roboPaint);
		roboPaint.setLinearText(true);

		digitalPaint = new Paint();
		digitalPaint.setColor(Color.GREEN);
		digitalPaint.setTextSize(mDigitalTextSize);
		////Typeface digitalPaintTF = Typeface.createFromAsset(context.getAssets(), "fonts/LetsGoDigital.ttf");
	
		Typeface digitalPaintTF = Typeface.create("Ariel", Typeface.NORMAL);
		digitalPaint.setTypeface(Typeface.create(digitalPaintTF, Typeface.BOLD));
		
		digitalPaint.setTextAlign(Align.LEFT);

		//setLayerType(LAYER_TYPE_SOFTWARE, digitalPaint);
		//digitalPaint.setLinearText(true);
		
		Typeface scaleTF = Typeface.createFromAsset(context.getAssets(), "fonts/Mechanical.ttf");
		scalePaint = new Paint();
		scalePaint.setStyle(Paint.Style.FILL);
		scalePaint.setColor(Color.RED);
		scalePaint.setAntiAlias(true);
		//scalePaint.setTextSize(0.055675f);
        scalePaint.setTextSize(55f);
	    scalePaint.setTypeface(Typeface.create(scaleTF, Typeface.NORMAL));
	    //scalePaint.setTextScaleX(6f);
	    scalePaint.setTextAlign(Paint.Align.CENTER); 
	    scalePaint.setLinearText(true);
	        
	    labelPaint = new Paint();
	   // miscPaint.setTextSize(DRAWING_CACHE_QUALITY_AUTO);
	    labelPaint.setColor(Color.RED);
	    labelPaint.setTextSize(55f);
	    labelPaint.setAntiAlias(true);
	    labelPaint.setTextAlign(Align.LEFT);
	    labelPaint.setLinearText(true);
	    labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

	}
	
	public void setMph(float mph) {
		valMph = mph;
	}
    public void setVlt( float vlt ) { valVlt = vlt;}
	public void setOt( int ot ) {
		valOt = ot;
	}
	public void setCht(int cht) {
		valCht = cht;
	}
	public void setRpm(int rpm) {
		valRpm = rpm;
	}
	public void setOp( int op ) { valOp = op ; }
	
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		////Log.v("DigitalView", "onDraw()");
		float h = (float) getHeight();
        float w = (float) getWidth();
        canvas.save(Canvas.MATRIX_SAVE_FLAG);
       // canvas.scale(h , w);

		Paint p = new Paint();
		p.setStyle(Paint.Style.FILL);
		p.setColor(Color.BLACK);
		canvas.drawPaint(p);
        int scaledSize = getResources().getDimensionPixelSize(R.dimen.scalePaintDimen);
        Paint np = new Paint();
        np.setColor(Color.WHITE);
        scalePaint.setLinearText(true);
        scalePaint.setTextSize(scaledSize);
        np.setTextSize(scaledSize);
        /*
        canvas.drawText(String.valueOf(h),60,50,np);
        canvas.drawText(String.valueOf(w),100,50,np);
        */
		float valVoltage = 12.3f;
		float valAmb = 68.2f;

        addText(canvas, "Mph", String.valueOf(valMph), 0);
        addText(canvas, "Rpm", String.valueOf(valRpm),1);
        addText(canvas, "OT  F", String.valueOf(valOt),2);
        addText(canvas, "Oil PSI", String.valueOf(valOp),3);
        addText(canvas, "CHT F", String.valueOf(valCht),4);
        addText(canvas, "Volt",  String.valueOf(valVlt),5);
        addText(canvas, "Odom", String.valueOf(valOd),6);
        addText(canvas, "AFR", String.valueOf(valAfr),7);
		addText(canvas, "Amb",  String.valueOf(valAmb),8);

	}
	
	private void addText( Canvas canvas, String desc, String val, int index ) {
		
		float xd, yd, xv, yv;
		xd = 0.055f;
		xv = 0.30f;
		yd = (index * 0.09f) + 0.09f;
		yv = yd  ;
		
		//canvas.drawText(desc, xd, yd - 0.0221f, labelPaint);
		//canvas.drawText(val,  xv, yv, digitalPaint);
        canvas.drawText(desc, 100f,(90f * index) + 90f, scalePaint);
        canvas.drawText(val, 300f, (90f * index) + 90f, digitalPaint);
		
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		
		Log.d("DIGITALVIEW", "Width spec: " + MeasureSpec.toString(widthMeasureSpec));
		Log.d("DIGITALVIEW", "Height spec: " + MeasureSpec.toString(heightMeasureSpec));

	    int widthMode = MeasureSpec.getMode(widthMeasureSpec);
	    int widthSize = MeasureSpec.getSize(widthMeasureSpec);

	    int heightMode = MeasureSpec.getMode(heightMeasureSpec);
	    int heightSize = MeasureSpec.getSize(heightMeasureSpec);

	    int chosenWidth = chooseDimension(widthMode, widthSize);
	    int chosenHeight = chooseDimension(heightMode, heightSize);

	    int chosenDimension = Math.min(chosenWidth, chosenHeight);

	    Log.v("DIGIALVIEW", "Width " + widthSize + " Height " + heightSize + " ModeW " + widthMode + " ModeH " + heightMode);
	    
	   // if ( widthSize > 1000 )
	    //	setMeasuredDimension(widthSize,610);
	   // else
	    	//setMeasuredDimension(widthSize,1240);
	    setMeasuredDimension(widthSize,mHeight);
	}
	
	//
	// Determine the screen resolution
	// and set it as a property of the object.
	//
	public void screenResolution ( Context context ) {
		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		DisplayMetrics metrics = new DisplayMetrics();
		display.getMetrics(metrics);
		int width = metrics.widthPixels ;
		int height = metrics.heightPixels;
		//	int j[] = null;
		//	j[0] = width;
		//	j[1] = height;
		Log.v("DIGITALVIEW", "width " + width + " height " + height);
		mHeight = height;
		mWidth = width;
	}

	 private int chooseDimension(int mode, int size) {
	        if (mode == MeasureSpec.AT_MOST || mode == MeasureSpec.EXACTLY) {
	            return size;
	        } else { // (mode == MeasureSpec.UNSPECIFIED)
	            //return getPreferredSize();
	        	return size;
	        } 
	    }

	 // in case there is no size specified
	 private int getPreferredSize() {
	        return 550;
	 }
	 
}
