package com.resc.remgauge;

import android.view.View;

public class GlobalObject {

	public static int reboots = 4;
	public static View rootView;
	public static View viewPager;
	public int shutdowns = 10;
	public GlobalObject() {
		reboots = 14;
		shutdowns = 11;
		
	}
}
