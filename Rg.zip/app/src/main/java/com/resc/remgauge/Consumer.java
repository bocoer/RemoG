package com.resc.remgauge;




import com.resc.remgauge.Consumer.ViewType;


import android.util.Log;
import android.view.*;
import android.widget.TextView;

import static com.resc.remgauge.R.id.DigitalViewOt;


//
// This consumer class has a number of methods to set data, 
//  it then can dispatch GUI events based on that data.
//
public class Consumer {
	
	public enum ViewType {
		TEXTVIEW,
		GAUGEVIEW,
		DIGITALVIEW,
        GAUGEVIEW_SINGLE
	}

    public enum GaugeType {
        MPH,
        RPM,
        OIL_TEMP,
        OIL_PSI,
        CHT,
        ODOM,
        VOLT,
        AFT,
        AMBIENT,
        MAP
    }
	TestView mTestView = null;
	TextView mTextViewMph = null;
	TextView mTextViewDist = null;
	TextView mTextViewRpm = null;
	TextView mTextViewOt = null;
	TextView mTextViewCht = null;
	TextView mTextViewOp = null;
	TextView mTextViewAfr = null;
	TextView mTextViewAmbient = null;
	TextView mTextViewMesg = null;
	
	GaugeBuilder gbMph = null;
	GaugeBuilder gbOt = null;
	DigitalView dgView = null;
	View gbView = null;
	View txtView = null;

    //
    //
	private int valueOt = 0;
	private int valueCht = 0;
	private float valueMph = 0;
	private float valueDist = 0.0f;
	private int valueRpm = 0;
	private int valueOp = 0;
	private int valueAmbient = 0;
	private float valueVlt;
    //
    //
	static String valueInfoString = "+++";
	float factor = 0.2f;
	int mpaintOperation = 0;
	int iII = 225;
	static boolean running = false;
	int consInstance = 0;
	ViewType mViewType;
	
	private String tag() {
		return "CONSUMER" + consInstance;
	}
	
	public Consumer( View view ) {
		
		mTextViewOt = (TextView) view.findViewById(R.id.textViewOt);
		mTextViewCht = (TextView) view.findViewById(R.id.textViewCht);
		mTextViewDist = (TextView) view.findViewById(R.id.textViewDist);
		mTextViewOp  = (TextView) view.findViewById(R.id.textViewOp);
		mTextViewRpm = (TextView) view.findViewById(R.id.textViewRpm);
		mTextViewMph = (TextView) view.findViewById(R.id.textViewMph);
		mTextViewAfr = (TextView) view.findViewById(R.id.textViewAfr);
		mTextViewAmbient = (TextView) view.findViewById(R.id.textViewAmbient);
		mTextViewMesg = (TextView ) view.findViewById(R.id.textViewMesg);
		//gb = (GaugeBuilder) view.getRootView();
		txtView = view.getRootView();
		consInstance = 1;
    //    gbMph = (GaugeBuilder) view.findViewById(R.layout.ot_gauge);

       // gbMph.setUnitTitle("MPH");
		Log.v(tag(), "ctor 1");
		mViewType = ViewType.TEXTVIEW;
	}
	
	public Consumer( View view, ViewType vt) {

		//mTextViewOt = (TextView) view.findViewById(R.id.textView3);
		//mTextViewCht = (TextView) view.findViewById(R.id.textView2);
		//mTextViewMph = (TextView) view.findViewById(R.id.textViewMph);
		gbMph = (GaugeBuilder) view.findViewById(R.id.analogGauge1);
////		gbMph.setUnitTitle("MPH");
		gbOt =  (GaugeBuilder) view.findViewById(R.id.analogGauge2);

        if ( gbOt == null) { Log.v(tag(), "gbOt null"); return;}

        if ( gbMph == null) { Log.v(tag(), "gbMph null"); return;}

		//gbOt.setTotalNotches(200);
		gbOt.setScaleMinValue(0);
		gbOt.setScaleMaxValue(60);
		gbOt.setTotalNotches(100);
		gbOt.setIncrementPerLargeNotch(10);
		gbOt.setIncrementPerSmallNotch(1);
		gbOt.setScaleCenterValue(30);
		gbOt.setDegreesPerNotch();
		gbView = view;
		gbOt.setUnitTitle("OT");
		consInstance = 2;
		Log.v(tag(), "ctor 2");
        gbOt.setValue(33.0f);
        gbOt.postInvalidate();
		mViewType = ViewType.GAUGEVIEW;
	}
	
	public Consumer( TestView view, int paintOperation ) 
	{
		mpaintOperation = paintOperation;
		//view.getDisplay();
		//view.setXfact(10);
		
		//view.setC(20);
		
		mTestView = view;
		consInstance = 3;
		Log.v("Consumer", " ctor3 constuctor sets paint operation");
		
	}
	
	public Consumer() {
		consInstance = 4;
	}
    public Consumer(View rootView, ViewType vt, boolean doIt) {
        // TODO Auto-generated constructor stub
        gbMph = (GaugeBuilder) rootView.findViewById(R.id.analogGaugeOt);
        gbMph.setUnitTitle("F");
        gbMph.setUpperTitle("Ot");
        gbMph.setLowerTitle("--");
        gbView = rootView;
        gbMph.setScaleMinValue(150);
        gbMph.setScaleMaxValue(350);
        gbMph.setTotalNotches(200);
        gbMph.setIncrementPerLargeNotch(10);
        gbMph.setIncrementPerSmallNotch(1);
        gbMph.setScaleCenterValue(250);
        gbMph.setDegreesPerNotch();
        consInstance = 5;
        dgView = (DigitalView) rootView.findViewById(DigitalViewOt);
        Log.v(tag(), "ctor 2");
        mViewType = ViewType.GAUGEVIEW;
    }
	public Consumer(View rootView, GaugeBuilder gb, ViewType gaugeview) {
		// TODO Auto-generated constructor stub
		gbMph = (GaugeBuilder) rootView.findViewById(R.id.analogGauge1);
		gbMph.setUnitTitle("MPHddd");
		gbOt =  (GaugeBuilder) rootView.findViewById(R.id.analogGauge2);
		gbView = rootView;
		gbOt.setUnitTitle("OT");
		consInstance = 5;
		Log.v(tag(), "ctor 2");
		mViewType = ViewType.GAUGEVIEW;
	}

	public Consumer( View rootView, DigitalView dv ) {
		mViewType = ViewType.DIGITALVIEW;
		dgView = (DigitalView) rootView.findViewById(R.id.DigitalView2);
        Log.v(tag(),"ctor 4");
	}
	
	public void stop() {
		running = false;
	}
	public void setFactor( int f ) {
		factor = f;
	}
	public void setMph( float mph ) {
		valueMph = mph;
	}
	public void setDist( float d ) {
		valueDist = d;
	}
	public void setStringInfo ( String s ) {
		valueInfoString = s;
	}
	public void setCht( int headTemps ) {
		valueCht = headTemps;
	}
	public void setOt ( int temp ) {
		valueOt = temp;
	}
    public void setVlt ( float v ) { valueVlt = v; }

	//
	// Start consuming data and post messages to GUI widgets.
	//
	public void startProgress() {
		// 
		running = true;
		Runnable runnable = new Runnable() {
	    	@Override
	    	public void run() {
	    
	    		UpdateTextTask setText = new UpdateTextTask();
                //if ( txtView.isShown())
	    		  //  setText.run();

	    		int iters = 0;
	    		while ( running ) {

	    			if ( iters % 10 == 0 )
	    				Log.v(tag(), "true " + iters + "VT= " + mViewType);
	    			
	    			valueCht = (MathUtils.randInt(1,100)) + 200;
	    			valueOt = MathUtils.randInt(180, 240);
	    			valueRpm = MathUtils.randInt(800, 3500);
	    			valueOp = MathUtils.randInt(2, 60);
	    			valueVlt = (MathUtils.randInt(110,140))/ 10.0f;
	    			
	    			if ( gbMph != null ) {
	    				gbMph.setValue((float) valueOt);
	    				/////gbMph.setLowerTitle( Float.toString(valueRpm));
	    				//mTextViewMph222.post(setText222);
	    			}
	    			
	    			if ( gbOt != null ) { 
	    				//gbOt.setValue((float) valueMph);
                        gbOt.setValue(valueOt);
                        Log.v("DDDD", "SET VALUEEEE");
	    			}
	    			
	    			if ( dgView != null ) {
	    				dgView.setMph(valueMph);
	    				dgView.setOp(valueOp);
	    				dgView.setOt(valueOt);
	    				dgView.setRpm(valueRpm);
                        dgView.setVlt(valueVlt);
                        dgView.setCht(valueCht);
	    				dgView.postInvalidate();
	    			}
	    			
	    			doFakeWork();
	           
	    			if ( txtView != null ) {
	    			if ( mpaintOperation == 0 && txtView.isShown() ) {
	    				mTextViewOt.post(setText);
	    				mTextViewCht.post(setText);
	    				mTextViewMph.post(setText);
	    				//mTextView1.post(setText);

	    			} else {
	    				//mTestView.postInvalidate();
	    			}
	    			}
	    			if ( gbMph != null ) 
	    				gbMph.postInvalidate();
	    			
	    			if ( gbOt != null ) {
                        Log.v(tag(),"Invalidate() n null");
                        gbOt.postInvalidate();
                    }
	    			if ( dgView != null ) 
	    				dgView.postInvalidate();
	    			
	    			iters++;
	    		}
	    	}
	    
	    };
	    
	    
	    new Thread(runnable).start();
	    
	}

	//
	//
	//
	public class UpdateTextTask implements Runnable {
	     public void run() {
	    	 
	    	 if ( mpaintOperation == 0 ) {
	    		 
	    		 if ( mTextViewOt != null )
	    			 mTextViewOt.setText(     "Oil temp: " + valueOt + " F");
	    		 
	    		 if ( mTextViewCht != null )
	    			 mTextViewCht.setText(    "Cyl temp: " + valueCht + " F");
	    		 
	    		 if ( mTextViewMph != null )
	    			 mTextViewMph.setText(    "Speed:    " + valueMph + " Mph");
	    		 
	    		 if ( mTextViewRpm != null )
	    			 mTextViewRpm.setText(    "Rpm:      " + valueRpm + " p/min");
	    			 
	    		 if ( mTextViewDist != null ) 
	    			 mTextViewDist.setText(   "Odom:     " + valueDist + " Miles");
	    		 
	    		 if ( mTextViewAmbient != null ) 
	    			 mTextViewAmbient.setText("Ambient:  " + valueAmbient + " F");
	    		 
	    		 if ( mTextViewMesg != null ) 
	    			 mTextViewMesg.setText(valueInfoString);
	    		 
	    		 if ( mTextViewOp != null ) 
	    			 mTextViewOp.setText(     "Oil Pressure: " + valueOp + " psi");
	    		 
	    		 if ( mTextViewAfr != null )
	    			 mTextViewAfr.setText(   "Afr: " + MathUtils.randInt(0,10));
	         // do stuff here
	    	 
	    	 //Log.v("Consumer", "UpdateTextTask.run()" + " " + valueOt + " " + valueCht + " " + valueInfoString);
	    	 }
	     }
	}
	
	// 
	//
	//
	private void doFakeWork() {
	    try {
	      Thread.sleep((int)(factor * 1000f));
	    } catch (InterruptedException e) {
	      e.printStackTrace();
	    }
	  }

}
