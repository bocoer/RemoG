package com.resc.remgauge;

import java.util.Random;

public class MathUtils {

	static float mAve = -1;
	static Random mrand = new Random();
	
	public MathUtils() {
		mrand = new Random();
	}
	
	public static int randInt(int min, int max) {
		
		int r = mrand.nextInt((max-min)+1) + min;
		return r;
	}
	
	public static float movingAverage( float newval) {
		
		
		return mAve;
	}
}
